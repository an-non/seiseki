# 声析 ローカルLLM — 実ファイル一式

2026-08-22 現在。**リポジトリの根からの相対パスそのまま**で入っています。
`seiseki-project` の根に重ねれば、そのまま使えます。

---

## いま、これらが「どこにあるか」

### ① Cloudflare staging — **モデル一式は上がっています（公開・取得可）**

2026-08-21 04:05:29 UTC のデプロイ（Version `a6aab0d6-a5db-4c11-bfa4-308689cd9158`）で
反映済みです。ブラウザでそのまま開けます。

```
https://seiseki-api-staging.tokyo-odh-129.workers.dev/model/manifest.json
https://seiseki-api-staging.tokyo-odh-129.workers.dev/model/encoder-int8-v40k.bin
https://seiseki-api-staging.tokyo-odh-129.workers.dev/model/head-krr-full.bin
https://seiseki-api-staging.tokyo-odh-129.workers.dev/model/tok-data-v40k.json
https://seiseki-api-staging.tokyo-odh-129.workers.dev/model/kernel.wasm
https://seiseki-api-staging.tokyo-odh-129.workers.dev/model/bootstrap.js
https://seiseki-api-staging.tokyo-odh-129.workers.dev/model/model-store.js
https://seiseki-api-staging.tokyo-odh-129.workers.dev/model/store-fallback.js
https://seiseki-api-staging.tokyo-odh-129.workers.dev/model/local-client.js
https://seiseki-api-staging.tokyo-odh-129.workers.dev/model/worker.js
https://seiseki-api-staging.tokyo-odh-129.workers.dev/model/tokenizer.js
https://seiseki-api-staging.tokyo-odh-129.workers.dev/model/encoder-wasm.js
https://seiseki-api-staging.tokyo-odh-129.workers.dev/model/encoder.js
https://seiseki-api-staging.tokyo-odh-129.workers.dev/model/head-krr.js
https://seiseki-api-staging.tokyo-odh-129.workers.dev/model/local.js
https://seiseki-api-staging.tokyo-odh-129.workers.dev/model/chunks.js
https://seiseki-api-staging.tokyo-odh-129.workers.dev/model/_headers
```

**直接こちらで確認したもの**: `manifest.json`（版 `2026-08-19` / `total 21590104`）、
`model-store.js`（`takeWhole` 有り＝Range修正済み）、`kernel.wasm`（`Content-Type: application/wasm`）、
`encoder-int8-v40k.bin`（`200` / `19894720` バイト）。

### ② GitHub — **上げていません**

`https://github.com/an-non/seiseki` への push は **4回とも拒否**されました。

```
remote: access denied by the git proxy: an-non/seiseki is not in this session's
        authorized repository set, so the proxy will not inject a credential for it.
```

**GitHub の権限ではなく、Anthropic 側のプロキシによるセッション単位の書き込み制限**です。
fine-grained token は正常で clone は通り、リポジトリを公開にしても変わりませんでした。

**枝 `feat/local-llm-stage0-1`（4コミット）は、別途お渡しした
`seiseki-local-llm-branch.bundle`（19MB）に入っています。** そちらから push してください。

### ③ この zip

上の②の枝に入っているファイルのうち、**ローカルLLMに関わるものだけ**を抜き出したものです。
生成物（`app/seiseki.jsx` / `local/src/App.jsx`）は含めていません。
`node scripts/build-app.mjs` で作り直せます。

---

## 置き場所と役目

| パス | 状態 | 役目 |
|---|---|---|
| `local/public/model/` | 新規17ファイル | モデル本体4＋実行系JS11＋`manifest.json`＋`_headers` |
| `core/seiseki-local-bridge.js` | **新規** | 唯一の継ぎ目。勝手に受け取らない／待たない／20秒で打ち切る |
| `core/ui.jsx` | 変更 | 受け取りUI3か所・表示バグ2件修正・追記もCloudflareへ |
| `core/logic.js` | 変更 | `sanitizeAnalysis` が `cap` と `band` を落とさない |
| `local/index.html` | 変更 | モデル用スクリプト4本を `main.jsx` より先に読む |
| `scripts/build-app.mjs` | 変更 | 連結対象に bridge を追加（+1行） |
| `tests/local-bridge.test.js` | **新規** | 9項目。依存なしで動く |
| `local/.env.staging.example` | **新規** | `VITE_SEISEKI_API_BASE` の見本 |
| `.github/workflows/deploy-staging.yml` | **新規** | `deploy/staging` への push か手動起動でのみ動く |

`core/ui.jsx` は **他の方の「量子観測」タブの変更を取り込み済み**です
（`feature/quantum-app-integration` の `d95e7d0` と3方向マージ。衝突ゼロ）。

---

## 照合用の指紋（SHA256）

```
1169794c1993645ba4c2d76452112d078345858ad9bc2e7a179f02799606f09b  .github/workflows/deploy-staging.yml
24006c61c8d208496a3034fac42e62ca4ce2c3184e238c881774e895424468a0  core/logic.js
07cdf644fdf429aaf17807cab41936c8edba6e6536941b491ee9760a6a6435c0  core/seiseki-local-bridge.js
b326f647eabbd5f8504351fe36cba152c1b4a55160b78c4bfd0922f7190c031e  core/ui.jsx
2d322b553b31e2421f8d9716154bced2a19d989893efe741cb23993aed5ffed4  local/.env.staging.example
810c3f15ddc67626a1ae1a5172b97459351c2cb613c0d13c26b0c049034b655a  local/index.html
b579ec57fe4b8ba7d00fe2f0944d87173d4e63a28aa8c5df3ec4843e4e1b62f5  local/public/model/_headers
752d9af7db940899193eb531b3ef7ac80f19220025e800d09c489904afb7e16c  local/public/model/bootstrap.js
22eb42642af914ae0ca429605ffd352a83dc195084bfc9ceff5903ab1420256f  local/public/model/chunks.js
d287b77d03d3d18f2bb0db0d26e92ee60c18b51e511ddd5ae278669ddd0c5a6b  local/public/model/encoder-int8-v40k.bin
bfe964a6b6285de9cc621337cd136787421ef16b5989198041d296369ef7a662  local/public/model/encoder-wasm.js
0ac85fd954bdf4bcf6c58998ac02e7a93e560303c2a7217e16c7cc7baf75e141  local/public/model/encoder.js
201c093e3deb8778f92c635025a8ee67bb7d721c87e7c69c735c846fc204f26d  local/public/model/head-krr-full.bin
9e6bd95f6653e4ea79fcb808ec637f3b078b3f08bee41194e7799fe984eee29f  local/public/model/head-krr.js
c9de32f0fd046cee0674c283603621f30fbcb5f4cb75b6be07369f21df1a2aae  local/public/model/kernel.wasm
10c56c8f9a5454b787972b89552d7c31924aa3cc36fb451086497d9735a8f467  local/public/model/local-client.js
98169ffb764827a3e731f00f664df4ea3283ef1e362b24a996c9c7ac6ece8d4c  local/public/model/local.js
d5422160101e8acb828e2f036a5b1151b896932cb9dfe77e3c80dde2921dfded  local/public/model/manifest.json
cac3b9465f94d1c7635143ee5ea042ea03c6a70a4ae1496fe0df6315327d7f85  local/public/model/model-store.js
923cfd31045846fedb3ec67ec728fe54484dca2ac58d396138c5745846fe9410  local/public/model/store-fallback.js
2cd362a6e30c0aa6b336314d6eec66df9bb51cfebb03f5d6d1879d9849de912a  local/public/model/tok-data-v40k.json
9f0237e79fb50f5dcc352438c60c5f9da8013cc75d7ecc139ac11dfe4de25d18  local/public/model/tokenizer.js
f194b32b83cfcdf5c289fc96db7da231f361433ae4dc7c95563a0851b0567cd0  local/public/model/worker.js
4efd0704f498e37543b6dbcf864ea9e4d46f085bc328aa84893f7b471c0cf815  scripts/build-app.mjs
b661e365304ef9666dbbe9b26c56bd3632cf1904d91ea747617b3b5ff0c15162  tests/local-bridge.test.js
```

`manifest.json` に載っているモデル4ファイルの指紋は、そのまま
Cloudflare 上のファイルと一致します（`local/public/model/` と同じものが配信されています）。

---

## 権利表示について（未対応・要対応）

エンコーダは **`sbintuitions/modernbert-ja-30m`（MIT）** を int8量子化＋語彙剪定して
詰め直したものです。重みは一切学習していません。

**MIT の著作権表示が同梱されていません。** 公開前に
`local/public/model/LICENSE-modernbert-ja-30m.txt` を置いてください。
入手元: `https://huggingface.co/sbintuitions/modernbert-ja-30m`

教師データの出典は `総括-ローカルLLM実装-20260822.md` の §5 にまとめてあります。
